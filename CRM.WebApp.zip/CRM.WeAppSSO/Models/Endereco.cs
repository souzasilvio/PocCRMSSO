﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CRM.WeAppSSO.Models
{
    public class Endereco
    {
        public string Cep { get; set; }
        public string Logradouro { get; set; }
    }
}